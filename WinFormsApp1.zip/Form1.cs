using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private static Dictionary<string, string> users = new Dictionary<string, string>();



        private void button1_Click_1(object sender, EventArgs e)
        {
            string newUser = textBox1.Text;
            string newPass = textBox2.Text;
            if (string.IsNullOrWhiteSpace(newUser) || string.IsNullOrWhiteSpace(newPass))
            {
                MessageBox.Show("Please enter both username and password.", "bildiris", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (users.ContainsKey(newUser))
            {
                MessageBox.Show("User already exists.", "bildiris", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                users.Add(newUser, newPass);
                MessageBox.Show("User registered successfully.", "bildiris", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string inUser = textBox3.Text;
            string inPass = textBox4.Text;

            if (users.ContainsKey(inUser) && users[inUser] == inPass)
            {
                MessageBox.Show("Login successful.", "bildiris", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Invalid username or password.", "bildiris", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            textBox3.Clear();
            textBox4.Clear();
        }
    }
        
    }
   